package com.fer.jms.security;

import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Topic;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

import com.fer.jms.hr.Employee;

public class SecurityApp {

	public static void main(String[] args) throws NamingException, JMSException, InterruptedException {
			InitialContext initialContext = new InitialContext();
			Topic topic = (Topic) initialContext.lookup("topic/empTopic");
			
			try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();
					JMSContext jmsContext = cf.createContext()){
				
				jmsContext.setClientID("securityApp");
				JMSConsumer consumer = jmsContext.createDurableConsumer(topic,"subscription1");
				//simulate the subscriber is down
				consumer.close();
				Thread.sleep(10000);
				
				//by doing the same subscription name subscription1 jms provider will see that existed before so it will recover the same consumer
				consumer = jmsContext.createDurableConsumer(topic,"subscription1");
				Message message = consumer.receive();
				Employee employee = message.getBody(Employee.class);
				System.out.println(employee.getFirstName());
				
				consumer.close();
				//once you unsubscribe it will be removed from the jms provider tracking, if you try again
				//jmsContext.createDurableConsumer(topic,"subscription1"); it will be like if it is the first time it has been subscribed
				jmsContext.unsubscribe("subscription1");
			}
	}

}
