package com.fer.jms.hr;

import javax.jms.JMSContext;
import javax.jms.Topic;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

public class HRApp {

	public static void main(String[] args) throws NamingException {
			InitialContext initialContext = new InitialContext();
			Topic topic = (Topic) initialContext.lookup("topic/empTopic");
			
			try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();
					JMSContext jmsContext = cf.createContext()){
				
				Employee employee = new Employee();
				employee.setId(123);
				employee.setFirstName("Fer");
				employee.setLastName("Arellano");
				employee.setDesignation("Architect");
				employee.setEmail("fer@fer.com");
				employee.setPhone("3333333333");
				
				for(int i=0; i<10;i++) {
					jmsContext.createProducer().send(topic, employee);
				}
				
				System.out.println("Message sent"); 
			}
	}

}
