package com.fer.jms.basics;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class FirstQueue {

	public static void main(String[] args) {

		InitialContext initialContext = null;
		Connection connection = null;
				
		try {
			//it will automatically use the information from jndi.properties
			initialContext= new InitialContext();
			//from the jndi properties property connectionFactory.ConnectionFactory
			ConnectionFactory cf = (ConnectionFactory) initialContext.lookup("ConnectionFactory");
			connection = cf.createConnection();
			Session session = connection.createSession();
			//from the jndi properties property queue.queue/myQueue
			Queue queue = (Queue)initialContext.lookup("queue/myQueue");
			
			//Message Producer
			MessageProducer producer = session.createProducer(queue);
			TextMessage message = session.createTextMessage("Fer Message");
			producer.send(message);
			System.out.println("message sent: " + message.getText());
			
			//MessageConsumer
			MessageConsumer consumer = session.createConsumer(queue);
			//we are ready to consume the messages (we are ready to receive messages)
			connection.start();
			
			TextMessage messageReceived = (TextMessage)consumer.receive(5000);
			System.out.println("message received: " + messageReceived.getText());
			
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(initialContext!= null) {
				try {
					initialContext.close();
				} catch (NamingException e) {
					e.printStackTrace();
				}
			}
			if(connection!= null) {
				try {
					connection.close();
				}  catch (JMSException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
